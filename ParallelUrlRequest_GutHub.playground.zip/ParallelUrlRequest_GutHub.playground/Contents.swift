//  Created by Dmitriy Ignatyev on 07/05/2019.
//  Copyright © 2019 Dmitriy Ignatyev. All rights reserved.

import Dispatch

// All examples are at the end of the file. Tap 'play' button and scroll down:)

enum ApiError: Error {
    case errorStub
}

/** A group of simple methods that solves routine problem: run several api requests in parallel and then combine their results */
enum ParrallelActions {
    static var defaultCompletionQueue: CompletionQueueKind { return .global(.userInitiated) }
    
    /// All actions are nonEscaping and does not reatin objects.
    static func combine<A, B>(_ aAction: (_ completion: @escaping (A) -> Void) -> Void,
                              _ bAction: (_ completion: @escaping (B) -> Void) -> Void,
                              completeOnQueue queueKind: CompletionQueueKind = defaultCompletionQueue,
                              completion: @escaping (A, B) -> Void) {
        let dispatchGroup = DispatchGroup()
        
        var maybeA: A?
        var maybeB: B?
        
        dispatchGroup.enter()
        let completionA: (A) -> Void = { value in
            maybeA = value
            dispatchGroup.leave()
        }
        aAction(completionA)
        
        
        dispatchGroup.enter()
        let completionB: (B) -> Void = { value in
            maybeB = value
            dispatchGroup.leave()
        }
        bAction(completionB)
        
        dispatchGroup.notify(queue: getDispatchQueue(ofKind: queueKind)) {
            guard let aValue = maybeA, let bValue = maybeB else { return }
            
            completion(aValue, bValue)
        }
    }
    
    /// All actions are nonEscaping and does not reatin objects.
    static func combine<A, B, C>(_ aAction: (_ completion: @escaping (A) -> Void) -> Void,
                                 _ bAction: (_ completion: @escaping (B) -> Void) -> Void,
                                 _ cAction: (_ completion: @escaping (C) -> Void) -> Void,
                                 completeOnQueue queueKind: CompletionQueueKind = defaultCompletionQueue,
                                 completion: @escaping (A, B, C) -> Void) {
        let dispatchGroup = DispatchGroup()
        
        var maybeA: A?
        var maybeB: B?
        var maybeC: C?
        
        dispatchGroup.enter()
        let completionA: (A) -> Void = { value in
            maybeA = value
            dispatchGroup.leave()
        }
        aAction(completionA)
        
        
        dispatchGroup.enter()
        let completionB: (B) -> Void = { value in
            maybeB = value
            dispatchGroup.leave()
        }
        bAction(completionB)
        
        dispatchGroup.enter()
        let completionC: (C) -> Void = { value in
            maybeC = value
            dispatchGroup.leave()
        }
        cAction(completionC)
        
        dispatchGroup.notify(queue: getDispatchQueue(ofKind: queueKind)) {
            guard let aValue = maybeA, let bValue = maybeB, let cValue = maybeC else { return }
            
            completion(aValue, bValue, cValue)
        }
    }
    
    enum CompletionQueueKind {
        case main
        case global(DispatchQoS.QoSClass)
    }
    
    private static func getDispatchQueue(ofKind kind: CompletionQueueKind) -> DispatchQueue {
        switch kind {
        case .main: return .main
        case .global(let qos): return .global(qos: qos)
        }
    }
}

// MARK: Flatmap Success

/** Switches all results one by one and combines 'success' values.
 If all results succeded then .success will be returned.
 If at least one result failed, then .failure will be returned. */
func combinedSuccess<A, B, Error>(of a: Result<A, Error>,
                                  _ b: Result<B, Error>) -> Result<(A, B), Error> where Error: Swift.Error {
    switch a {
    case .success(let aValue):
        switch b {
        case .success(let bValue): return .success((aValue, bValue))
        case .failure(let error): return .failure(error)
        }
    case .failure(let error): return .failure(error)
    }
}


func combinedSuccess<A, B, C, Error>(of a: Result<A, Error>,
                                     _ b: Result<B, Error>,
                                     _ c: Result<C, Error>) -> Result<(A, B, C), Error> where Error: Swift.Error {
    switch a {
    case .success(let aValue):
        switch b {
        case .success(let bValue):
            switch c {
            case .success(let cValue): return .success((aValue, bValue, cValue))
            case .failure(let error): return .failure(error)
            }
        case .failure(let error): return .failure(error)
        }
    case .failure(let error): return .failure(error)
    }
}

// MARK: - Examples

// Imitation of ApiManager (Moya / Alamofire / ...)
final class MoyaProvierMok {
    
    func loadTariff(completion: @escaping (Result<String, ApiError>) -> Void) {
        DispatchQueue.global(qos: .default).asyncAfter(deadline: .now() + 1) {
            completion(.success("Tariff\(Int.random(in: 10...99))"))
        }
    }
    
    func loadProfile(completion: @escaping (Result<String, ApiError>) -> Void) {
        DispatchQueue.global(qos: .default).asyncAfter(deadline: .now() + 1.5) {
            completion(.success("UserProfile\(Int.random(in: 10...99))"))
        }
    }
    
    func obtainAuthInfo(completion: @escaping (Result<String, ApiError>) -> Void) {
        DispatchQueue.global(qos: .default).asyncAfter(deadline: .now() + 2) {
            completion(.success("Token\(Int.random(in: 10...99))"))
        }
    }
}

let moyaProvider = MoyaProvierMok()

// Wrap every Api-request with a non-escaping closure:
let tariffRequest: (@escaping (Result<String, ApiError>) -> Void) -> Void = {
    moyaProvider.loadTariff(completion: $0)
}

let profileRequest: (@escaping (Result<String, ApiError>) -> Void) -> Void = {
    moyaProvider.loadProfile(completion: $0)
}

let authInfoRequest: (@escaping (Result<String, ApiError>) -> Void) -> Void = {
    moyaProvider.obtainAuthInfo(completion: $0)
}

do {
    // MARK: Simple example. Combine 3 Api requests:
    
    ParrallelActions.combine(tariffRequest, profileRequest, authInfoRequest, completeOnQueue: .global(.default)) { tariff, profile, authInfo in
        let finalResult = combinedSuccess(of: tariff, profile, authInfo)
        
        switch finalResult {
        case .failure(let error):
            print(error)
        case let .success(tariff, profile, authInfo):
            print("Simple combine: \(tariff), \(profile), \(authInfo)")
        }
    }
}

do {
    // MARK: Example of complex combine: 6 Api requests
    
    let combinedRequest1: (@escaping (Result<(String, String, String), ApiError>) -> Void) -> Void = { completion in
        ParrallelActions.combine(tariffRequest, profileRequest, authInfoRequest) { tariff, profile, authInfo in
            let finalResult = combinedSuccess(of: tariff, profile, authInfo)
            completion(finalResult)
        }
    }
    
    let combinedRequest2: (@escaping (Result<(String, String, String), ApiError>) -> Void) -> Void = { completion in
        ParrallelActions.combine(tariffRequest, profileRequest, authInfoRequest) { tariff, profile, authInfo in
            let finalResult = combinedSuccess(of: tariff, profile, authInfo)
            completion(finalResult)
        }
    }
    
    // and even more: combinedRequest3, combinedRequest4...
    
    ParrallelActions.combine(combinedRequest1, combinedRequest2) { resul1, resul2 in
        let finalResult = combinedSuccess(of: resul1, resul2)
        
        switch finalResult {
        case .failure(let error):
            print(error)
        case let .success(first, second):
            
            let (tariff0, profile0, authInfo0) = first
            let (tariff1, profile1, authInfo1) = second
            
            print("Complex combine: \(tariff0), \(profile0), \(authInfo0), \(tariff1), \(profile1), \(authInfo1)")
        }
    }
}
